
<DOCTYPE html>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		

		<title>Login Form</title>

	</head>
<body>






	<div class="loginform">
		<img src="avatar.jpg";>
		<form>
                <div class="form-input">
				<i class="fa fa-user fa-2x cust" aria-hidden="true"></i>
				<input type="text" name="uname" value="" placeholder="Enter Username"><br />
				<i class="fa fa-lock fa-2x cust" aria-hidden="true"></i>
				<input type="password" name="pass" value="" placeholder="Enter Password"><br />
				<input type="submit" onclick="check(this.form)" value="LOGIN"/><br />
				<a href="#">Forget Password</a><br />
			    </div>
			
		</form><br>
	</div>




  <script src="link.php"></script> 

</body>
	</html>